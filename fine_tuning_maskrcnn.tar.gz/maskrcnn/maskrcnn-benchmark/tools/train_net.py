# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
r"""
Basic training script for PyTorch
"""

# Set up custom environment before nearly anything else is imported
# NOTE: this should be the first import (no not reorder)
from maskrcnn_benchmark.utils.env import setup_environment  # noqa F401 isort:skip

import argparse
import os
import time
# import sys
# sys.path.append('..')

import logging
import torch
from maskrcnn_benchmark.config import cfg
from maskrcnn_benchmark.data import make_data_loader
from maskrcnn_benchmark.solver import make_lr_scheduler
from maskrcnn_benchmark.solver import make_optimizer
from maskrcnn_benchmark.engine.inference import inference
from maskrcnn_benchmark.engine.trainer import do_train, do_eval
from maskrcnn_benchmark.modeling.detector import build_detection_model
from maskrcnn_benchmark.utils.checkpoint import DetectronCheckpointer
from maskrcnn_benchmark.utils.collect_env import collect_env_info
from maskrcnn_benchmark.utils.comm import synchronize, get_rank
from maskrcnn_benchmark.utils.imports import import_file
from maskrcnn_benchmark.utils.logger import setup_logger
from maskrcnn_benchmark.utils.miscellaneous import mkdir
from maskrcnn_benchmark.utils.save_load_model import read_pickle

PKL_READ_PATH = '/home/skhawy/skhawy/ADL4CV/maskrcnn/maskrcnn-benchmark/models/'


def change_net_heads(model, subset_num_classes= 4):
    model.roi_heads.box.predictor.cls_score = torch.nn.Linear(in_features=1024,
                                                              out_features=subset_num_classes, bias=True)

    model.roi_heads.box.predictor.bbox_pred = torch.nn.Linear(in_features=1024,
                                                              out_features=subset_num_classes * 4, bias=True)

    model.roi_heads.mask.predictor.mask_fcn_logits = torch.nn.Conv2d(256, subset_num_classes,
                                                                     kernel_size=(1, 1), stride=(1, 1))

def freeze_all_model(model):
    for params in model.parameters():
        params.requires_grad = False

def release_all_model(model):
    for params in model.parameters():
        params.requires_grad = True


def freeze_backbone_rpn(model):
    for params in model.backbone.parameters():
        params.requires_grad = False

    for params in model.rpn.parameters():
        params.requires_grad = False


def make_trainable_layers(model):
    for params in model.roi_heads.box.predictor.cls_score.parameters():
        params.requires_grad = True

    for params in model.roi_heads.box.predictor.bbox_pred.parameters():
        params.requires_grad = True

    for params in model.roi_heads.mask.predictor.mask_fcn_logits.parameters():
        params.requires_grad = True



def train(cfg, local_rank, distributed):
    model = build_detection_model(cfg)
    save_dir = cfg.OUTPUT_DIR

    checkpointer = DetectronCheckpointer(cfg, model, save_dir=save_dir)
    _ = checkpointer.load(cfg.MODEL.WEIGHT)

    subset_num_classes = cfg.MODEL.ROI_BOX_HEAD.SUBSET_NUM_CLASSES

    #1- Freeze the whole model
    freeze_all_model(model)

    #2- Change the model heads (box, mask, cls_scores)
    change_net_heads(model, subset_num_classes)

    #3- Make these layers trainable (by default when you create them, requires_grad = True but just in case)
    make_trainable_layers(model)

    device = torch.device(cfg.MODEL.DEVICE)
    model.to(device)

    #optimizer = make_optimizer(cfg, model)
    optimizer = torch.optim.SGD(list(model.parameters()), lr=1e-3)
    #scheduler = make_lr_scheduler(cfg, optimizer)
    scheduler = None


    # load the model our way
    read_pickle(PKL_READ_PATH, model, optimizer)

    if distributed:
        model = torch.nn.parallel.DistributedDataParallel(
            model, device_ids=[local_rank], output_device=local_rank,
            # this should be removed if we update BatchNorm stats
            broadcast_buffers=False,
        )

    arguments = {}
    arguments["iteration"] = 0

    output_dir = cfg.OUTPUT_DIR

    save_to_disk = get_rank() == 0

    # The model passed to the function has the weights loaded already
    # checkpointer = DetectronCheckpointer(
    #     cfg, model, optimizer, scheduler, output_dir, save_to_disk
    # )
    # extra_checkpoint_data = checkpointer.load(cfg.MODEL.WEIGHT)
    # arguments.update(extra_checkpoint_data)

    data_loader = make_data_loader(
        cfg,
        is_train=True,
        is_distributed=distributed,
        start_iter=arguments["iteration"],
    )

    checkpoint_period = cfg.SOLVER.CHECKPOINT_PERIOD

    num_epochs = cfg.NUM_EPOCHS

    for epoch in range(num_epochs):
        # do_train : trains one epoch now because we break after the max iteration
        # do_eval : validates one epoch because we break after the max iteration
        if epoch == 1:
            release_all_model(model)
            freeze_backbone_rpn(model)
            #change learning rate
            print("changing learning rate to 1e-4")
            for g in optimizer.param_groups:
                g['lr'] = 1e-4

        do_train(
            model,
            data_loader,
            optimizer,
            scheduler,
            checkpointer,
            device,
            checkpoint_period,
            arguments,
            epoch)


        arguments = {}
        arguments["iteration"] = 0
        if distributed:
            model = model.module

        data_loaders_val = make_data_loader(cfg, is_train=False, is_distributed=distributed)

        do_eval(model,
                data_loaders_val[0],
                optimizer,
                checkpointer,
                device,
                checkpoint_period,
                arguments,
                epoch)
    return model


def test(cfg, model, distributed):
    if distributed:
        model = model.module
    torch.cuda.empty_cache()  # TODO check if it helps
    iou_types = ("bbox",)
    if cfg.MODEL.MASK_ON:
        iou_types = iou_types + ("segm",)
    output_folders = [None] * len(cfg.DATASETS.TEST)
    dataset_names = cfg.DATASETS.TEST
    if cfg.OUTPUT_DIR:
        for idx, dataset_name in enumerate(dataset_names):
            output_folder = os.path.join(cfg.OUTPUT_DIR, "inference", dataset_name)
            mkdir(output_folder)
            output_folders[idx] = output_folder
    data_loaders_val = make_data_loader(cfg, is_train=False, is_distributed=distributed)
    for output_folder, dataset_name, data_loader_val in zip(output_folders, dataset_names, data_loaders_val):
        inference(
            model,
            data_loader_val,
            dataset_name=dataset_name,
            iou_types=iou_types,
            box_only=cfg.MODEL.RPN_ONLY,
            device=cfg.MODEL.DEVICE,
            expected_results=cfg.TEST.EXPECTED_RESULTS,
            expected_results_sigma_tol=cfg.TEST.EXPECTED_RESULTS_SIGMA_TOL,
            output_folder=output_folder,
        )
        synchronize()


def main():
    parser = argparse.ArgumentParser(description="PyTorch Object Detection Training")
    parser.add_argument(
        "--config-file",
        default="",
        metavar="FILE",
        help="path to config file",
        type=str,
    )
    parser.add_argument("--local_rank", type=int, default=0)
    parser.add_argument(
        "--skip-test",
        dest="skip_test",
        help="Do not test the final model",
        action="store_true",
    )
    parser.add_argument(
        "opts",
        help="Modify config options using the command-line",
        default=None,
        nargs=argparse.REMAINDER,
    )

    args = parser.parse_args()

    num_gpus = int(os.environ["WORLD_SIZE"]) if "WORLD_SIZE" in os.environ else 1
    args.distributed = num_gpus > 1

    if args.distributed:
        torch.cuda.set_device(args.local_rank)
        torch.distributed.init_process_group(
            backend="nccl", init_method="env://"
        )

    cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)
    cfg.freeze()

    output_dir = cfg.OUTPUT_DIR
    if output_dir:
        mkdir(output_dir)

    # added logger for to create a dataframe with all losses and statistics

    df_logger = logging.getLogger("df_training_maskrcnn")
    handler = logging.FileHandler("./logs/df_logger.log", 'w+')
    df_logger.addHandler(handler)
    df_logger.setLevel(logging.INFO)

    df_logger.info("epoch_num | iteration | loss | loss_classifier | loss_box_reg | loss_mask | loss_objectness | loss_rpn_box_reg | time | data | Flag")
    # ----------------------------------------------------------------------------------------------------

    logger = setup_logger("maskrcnn_benchmark", output_dir, get_rank())
    logger.info("Using {} GPUs".format(num_gpus))
    logger.info(args)

    logger.info("Collecting env info (might take some time)")
    logger.info("\n" + collect_env_info())

    logger.info("Loaded configuration file {}".format(args.config_file))
    with open(args.config_file, "r") as cf:
        config_str = "\n" + cf.read()
        logger.info(config_str)
    logger.info("Running with config:\n{}".format(cfg))

    model = train(cfg, args.local_rank, args.distributed)

    # if not args.skip_test:
    #     test(cfg, model, args.distributed)
    #     pass

if __name__ == "__main__":
    main()
