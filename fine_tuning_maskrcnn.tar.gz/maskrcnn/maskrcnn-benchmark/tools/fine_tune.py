# import torch
# import torch.nn as nn
#
#
# from maskrcnn_benchmark.config import cfg
# #from predictor import COCODemo
#
# # Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
# import sys
# sys.path.append('..')
# import cv2
# import torch
# from torchvision import transforms as T
#
# from maskrcnn_benchmark.modeling.detector import build_detection_model
# from maskrcnn_benchmark.utils.checkpoint import DetectronCheckpointer
# from maskrcnn_benchmark.structures.image_list import to_image_list
# from maskrcnn_benchmark.modeling.roi_heads.mask_head.inference import Masker
# from maskrcnn_benchmark import layers as L
#
#
#
# config_file = "../configs/caffe2/mine_fine_tune_coco.yaml"
#
# # update the config options with the config file
# cfg.merge_from_file(config_file)
#
# class FineTune(object):
#     def __init__(self,cfg):
#
#         self.cfg = cfg.clone()
#         self.model = build_detection_model(cfg)
#         #self.model.eval()
#
#
#         save_dir = cfg.OUTPUT_DIR
#         self.checkpointer = DetectronCheckpointer(cfg, self.model, save_dir=save_dir)
#         _ = self.checkpointer.load(cfg.MODEL.WEIGHT)
#
#         self.model.roi_heads.box.predictor.cls_score = nn.Linear(in_features=1024,
#                                                                  out_features=3, bias=True)
#
#         self.model.roi_heads.box.predictor.bbox_pred = nn.Linear(in_features=1024,
#                                                                  out_features=12, bias=True)
#
#         self.model.roi_heads.mask.predictor.mask_fcn_logits = nn.Conv2d(256, 3,
#                                                                         kernel_size=(1, 1), stride=(1, 1))
#
#         self.device = torch.device(cfg.MODEL.DEVICE)
#         self.model.to(self.device)