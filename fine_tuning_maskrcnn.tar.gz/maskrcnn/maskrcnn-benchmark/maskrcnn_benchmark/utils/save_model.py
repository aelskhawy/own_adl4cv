import torch
import os 

def save_new_pickle(path, epoch, model, solver):
    if not os.path.exists(path):
        os.makedirs(path)

    with open(path + "/model_" + str(epoch) + ".pkl", "wb") as f:
        print("#"*100)
        print("Saving the model")
        print("#" * 100)
        torch.save(model.state_dict(), f)
    with open(path + "/optim_" + str(epoch) + ".pkl", "wb") as f:
        print("#" * 100)
        print("Saving the Solver")
        print("#" * 100)
        torch.save(solver.state_dict(), f)

def read_pickle(path, model, solver):
    try:

        files = os.listdir(path)
        file_list = [int(file.split('_')[-1].split('.')[0]) for file in files]
        file_list.sort()
        recent_iter = str(file_list[-1])
        print("recent iteration {} ; path {}".format(recent_iter, path))

        with open(path + "/model_" + recent_iter + ".pkl", "rb") as f:
            model.load_state_dict(torch.load(f))
            print("#" * 100)
            print("Done loading model {:.4}".format(recent_iter))
        with open(path + "/optim_" + recent_iter + ".pkl", "rb") as f:
            print("#" * 100)
            print("Done loading solver {:.4}".format(recent_iter))
            solver.load_state_dict(torch.load(f))


    except Exception as e:
        print("#" * 100)
        print("fail try read_pickle", e)


