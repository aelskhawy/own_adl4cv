# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
import torch
import torchvision

from maskrcnn_benchmark.structures.bounding_box import BoxList
from maskrcnn_benchmark.structures.segmentation_mask import SegmentationMask
import os
from PIL import  Image
from maskrcnn_benchmark.config import cfg

only_our_classes = cfg.DATASETS.SUBSET_CLASSES
only_common_imgs = cfg.DATASETS.ONLY_COMMON_IMGS
remove_images_with_no_annotation_in_val = cfg.DATASETS.REMOVE_NO_ANNO_VAL

class COCODataset(torchvision.datasets.coco.CocoDetection):
    def __init__(
        self, ann_file, root, remove_images_without_annotations, transforms=None
    ):
        #super(COCODataset, self).__init__("/home/skhawy/skhawy/ADL4CV/maskrcnn/data/coco/train2017",
        #                                  "/home/skhawy/skhawy/ADL4CV/maskrcnn/data/coco/annotations/instances_train2017.json")
        # Omar, back to default paths

        super(COCODataset, self).__init__(root,
                                          ann_file)
        #cyclist in fine tune kitti instead of bicycle as i used the category "cyclist" while creating the annos for kitti dataset
        #['person', 'car', 'cyclist'] # kitti fine tuning
        self.ourcatNames = ['person', 'car', 'cyclist'] # coco fine tuning
        self.only_our_classes = only_our_classes
        self.remove_images_with_no_annotation_in_val = remove_images_with_no_annotation_in_val
        self.only_common_imgs = only_common_imgs

        if self.only_our_classes:
            print("Filtering classes")
            unique_ids = self.subset_classes()
            print("Len of unique IDs is ", len(unique_ids))
            self.ids = unique_ids # Taking only 10k image to save some time
            print("Len of IDs is ", len(self.ids))

        elif self.only_common_imgs:
            print("Picking only common Imgs")
            common_ids = self.subset_only_common_images()
            print("Len of common IDs is ", len(common_ids))
            self.ids = common_ids

        # sort indices for reproducible results
        self.ids = sorted(self.ids)

        # filter images without detection annotations
        if remove_images_without_annotations or self.remove_images_with_no_annotation_in_val:
            self.ids = [
                img_id
                for img_id in self.ids
                if len(self.coco.getAnnIds(imgIds=img_id, iscrowd=None)) > 0
            ]

        if self.only_common_imgs or self.only_our_classes:
            print(self.ourcatNames)
            self.json_category_id_to_contiguous_id = {
                v: i + 1 for i, v in enumerate(self.coco.getCatIds(catNms= self.ourcatNames))
            }
        else:
            self.json_category_id_to_contiguous_id = {
                v: i + 1 for i, v in enumerate(self.coco.getCatIds())  #
            }

        # print("*"*80)
        # print(self.coco.getCatIds(catNms= ['person', 'car', 'bicycle']))
        #print(self.json_category_id_to_contiguous_id)
        self.contiguous_category_id_to_json_id = {
            v: k for k, v in self.json_category_id_to_contiguous_id.items()
        }
        #print(self.contiguous_category_id_to_json_id)
        self.id_to_img_map = {k: v for k, v in enumerate(self.ids)}
        self.transforms = transforms

    def subset_only_common_images(self):
        '''Subsets only the images that contain all the objects we choose'''
        self.ourcatIds = self.coco.getCatIds(catNms=self.ourcatNames)
        #print(self.ourcatIds, self.ourcatNames)
        # self.ourcatIds.append(0)
        # print("our cat ids",self.ourcatIds)
        imgIds = self.coco.getImgIds(catIds=self.ourcatIds)
        # print(type(imgIds))
        # print(imgIds)
        return imgIds

    def subset_classes(self):
        self.ourcatIds = self.coco.getCatIds(catNms=self.ourcatNames)
        #self.ourcatIds.append(0)
        #print("our cat ids",self.ourcatIds)
        #aelskhawy
        our_ids = []
        for cat in self.ourcatNames:
            catIds = self.coco.getCatIds(catNms=cat)
            imgIds = self.coco.getImgIds(catIds=catIds)
            print("Number of images in category {} is {}".format(cat, len(imgIds)))
            our_ids += imgIds
        unique_ids = list(set(our_ids))

        return unique_ids

    def filter_anno_cats(self, index):
        coco = self.coco
        img_id = self.ids[index]

        ann_ids = coco.getAnnIds(imgIds=img_id,catIds=self.ourcatIds)
        target = coco.loadAnns(ann_ids)
        path = coco.loadImgs(img_id)[0]['file_name']

        img = Image.open(os.path.join(self.root, path)).convert('RGB')
        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target

    def __getitem__(self, idx):

        if self.only_our_classes or only_common_imgs:
            #print("Filtering annotations for our classes")
            img, anno = self.filter_anno_cats(idx)
        else:
            img, anno = super(COCODataset, self).__getitem__(idx)

        # filter crowd annotations
        # TODO might be better to add an extra field
        anno = [obj for obj in anno if obj["iscrowd"] == 0]

        boxes = [obj["bbox"] for obj in anno]
        boxes = torch.as_tensor(boxes).reshape(-1, 4)  # guard against no boxes
        target = BoxList(boxes, img.size, mode="xywh").convert("xyxy")

        classes = [obj["category_id"] for obj in anno]
        #print("classes",classes)
        #print("jason category",self.json_category_id_to_contiguous_id)
        # print('*'*100)
        # print(classes)
        classes = [self.json_category_id_to_contiguous_id[c] for c in classes]
        classes = torch.tensor(classes)
        target.add_field("labels", classes)

        masks = [obj["segmentation"] for obj in anno]
        masks = SegmentationMask(masks, img.size)
        target.add_field("masks", masks)

        target = target.clip_to_image(remove_empty=True)

        if self.transforms is not None:
            img, target = self.transforms(img, target)

        return img, target, idx

    def get_img_info(self, index):
        img_id = self.id_to_img_map[index]
        img_data = self.coco.imgs[img_id]
        return img_data
